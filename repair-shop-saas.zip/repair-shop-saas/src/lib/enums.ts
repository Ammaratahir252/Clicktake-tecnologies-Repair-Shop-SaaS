// Role definitions as per PDF
export enum Role {
  owner = 'owner',
  manager = 'manager',
  technician = 'technician',
  frontdesk = 'frontdesk',
  customer = 'customer',
  driver = 'driver',
}

// Ticket status for Module 2 & 5 dependency
export enum TicketStatus {
  received = 'received',
  diagnosed = 'diagnosed',
  estimate_sent = 'estimate_sent',
  approved = 'approved',
  in_repair = 'in_repair',
  ready = 'ready',
  delivered = 'delivered',
  cancelled = 'cancelled',
}

// Stock movement types for Inventory module
export enum StockMovement {
  added = 'added',
  used = 'used',
  adjusted = 'adjusted',
  returned = 'returned',
  damaged = 'damaged',
}